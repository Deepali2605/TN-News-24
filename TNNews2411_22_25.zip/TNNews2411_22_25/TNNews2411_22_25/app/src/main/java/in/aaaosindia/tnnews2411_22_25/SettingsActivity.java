package in.aaaosindia.tnnews2411_22_25;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Hide entire settings screen
        View root = findViewById(android.R.id.content);
        root.setVisibility(View.GONE);
    }
}
