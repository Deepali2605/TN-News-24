package in.aaaosindia.tnnews2411_22_25.network;

import java.util.List;

import in.aaaosindia.tnnews2411_22_25.data.Category;
import in.aaaosindia.tnnews2411_22_25.data.NewsItems;
import in.aaaosindia.tnnews2411_22_25.data.UserResponse;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {

    // ----------------------------
    // REAL WORDPRESS ENDPOINTS
    // ----------------------------

    @GET("wp-json/wp/v2/categories")
    Call<List<Category>> getCategories(@Query("per_page") int perPage);

    @GET("wp-json/wp/v2/posts")
    Call<List<NewsItems>> getPosts(
            @Query("per_page") int perPage,
            @Query("page") int page,
            @Query("_embed") boolean embed,
            @Query("orderby") String orderBy,
            @Query("order") String order,
            @Query("sticky") boolean sticky
    );

    @GET("wp-json/wp/v2/posts")
    Call<List<NewsItems>> getPostsByCategory(
            @Query("categories") int categoryId,
            @Query("per_page") int perPage,
            @Query("page") int page,
            @Query("_embed") boolean embed
    );

    @GET("wp-json/wp/v2/posts")
    Call<List<NewsItems>> getStickyPosts(
            @Query("sticky") boolean sticky,
            @Query("per_page") int perPage,
            @Query("page") int page,
            @Query("_embed") boolean embed
    );

    @GET("wp-json/wp/v2/posts")
    Call<List<NewsItems>> getSinglePost(
            @Query("include") int postId,
            @Query("_embed") boolean embed
    );

    @GET("wp-json/wp/v2/users/{id}")
    Call<UserResponse> getUser(@Path("id") int id);


    // ---------------------------------------
    // RAW ENDPOINTS (FOR FULL JSON STRING)
    // ---------------------------------------

    @GET("wp-json/wp/v2/categories")
    Call<ResponseBody> getCategoriesRaw(@Query("per_page") int perPage);

    @GET("wp-json/wp/v2/posts")
    Call<ResponseBody> getPostsRaw(
            @Query("per_page") int perPage,
            @Query("page") int page,
            @Query("_embed") boolean embed,
            @Query("orderby") String orderBy,
            @Query("order") String order,
            @Query("sticky") boolean sticky
    );

    @GET("wp-json/wp/v2/posts")
    Call<ResponseBody> getSinglePostRaw(
            @Query("include") int postId,
            @Query("_embed") boolean embed
    );

    @GET("wp-json/wp/v2/posts")
    Call<ResponseBody> getPostsByCategoryRaw(
            @Query("categories") int categoryId,
            @Query("per_page") int perPage,
            @Query("page") int page,
            @Query("_embed") boolean embed
    );

    @GET("wp-json/wp/v2/posts")
    Call<ResponseBody> getStickyRaw(
            @Query("sticky") boolean sticky,
            @Query("per_page") int perPage,
            @Query("page") int page,
            @Query("_embed") boolean embed
    );
}
