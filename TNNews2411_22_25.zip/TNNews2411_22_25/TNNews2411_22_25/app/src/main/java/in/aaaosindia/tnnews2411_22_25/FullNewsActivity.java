package in.aaaosindia.tnnews2411_22_25;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import java.util.ArrayList;
import java.util.List;

import in.aaaosindia.tnnews2411_22_25.data.NewsItems;
import in.aaaosindia.tnnews2411_22_25.network.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FullNewsActivity extends AppCompatActivity {

    ImageView imageView, backBtn, shareBtn;
    TextView titleTv, authorTv, dateTv;
    WebView webContent;
    ScrollView scrollView;

    private InterstitialAd mInterstitialAd;

    private final Handler adTimerHandler = new Handler();
    private final int AD_INTERVAL = 3 * 60 * 1000; // 3 minutes

    private Runnable showAdRunnable;

    List<NewsItems> fullList = new ArrayList<>();
    NewsItems currentItem;

    GestureDetector gestureDetector;
    int postId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_news);

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // Banner Ad
        AdView bannerAd = findViewById(R.id.bannerAdFull);
        AdRequest bannerRequest = new AdRequest.Builder().build();
        bannerAd.loadAd(bannerRequest);

        // Load the first interstitial
        loadInterstitial();

        imageView = findViewById(R.id.fullImage);
        backBtn = findViewById(R.id.backBtn);
        shareBtn = findViewById(R.id.shareBtn);
        titleTv = findViewById(R.id.fullTitle);
        authorTv = findViewById(R.id.fullAuthor);
        dateTv = findViewById(R.id.fullDate);
        webContent = findViewById(R.id.webContent);
        scrollView = findViewById(R.id.scrollView);

        getPostId();
        setupSwipe();

        backBtn.setOnClickListener(v -> finish());

        loadSinglePost();

        // ⭐ REPEATING AD EVERY 3 MINUTES
        showAdRunnable = new Runnable() {
            @Override
            public void run() {

                if (!isFinishing() && mInterstitialAd != null) {
                    mInterstitialAd.show(FullNewsActivity.this);
                }

                // Load next ad so it's ready for the next 3-min cycle
                loadInterstitial();

                // Schedule again
                adTimerHandler.postDelayed(this, AD_INTERVAL);
            }
        };

        // Start repeating timer
        adTimerHandler.postDelayed(showAdRunnable, AD_INTERVAL);
    }

    private void loadInterstitial() {
        AdRequest adRequest = new AdRequest.Builder().build();

        InterstitialAd.load(
                this,
                "ca-app-pub-5389304191356684/8402343002",  // Test ID — replace with your own later
                adRequest,
                new InterstitialAdLoadCallback() {

                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                        mInterstitialAd = null;
                    }
                }
        );
    }

    private void getPostId() {
        postId = getIntent().getIntExtra("postId", -1);

        Uri data = getIntent().getData();
        if (data != null) {
            for (String s : data.getPathSegments()) {
                s = s.split("\\?")[0];
                if (s.matches("\\d+")) postId = Integer.parseInt(s);
            }
        }

        if (postId == -1) {
            Toast.makeText(this, "Invalid news link", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void loadSinglePost() {
        RetrofitClient.getApiService()
                .getSinglePost(postId, true)
                .enqueue(new Callback<List<NewsItems>>() {
                    @Override
                    public void onResponse(Call<List<NewsItems>> call, Response<List<NewsItems>> response) {

                        if (response.body() == null || response.body().isEmpty()) {
                            Toast.makeText(FullNewsActivity.this, "Post not found", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        currentItem = response.body().get(0);
                        loadUI(currentItem);

                        loadAllPosts();
                    }

                    @Override
                    public void onFailure(Call<List<NewsItems>> call, Throwable t) {}
                });
    }

    private void loadAllPosts() {
        RetrofitClient.getApiService()
                .getPosts(100, 1, true, "date", "desc", false)
                .enqueue(new Callback<List<NewsItems>>() {
                    @Override
                    public void onResponse(Call<List<NewsItems>> call, Response<List<NewsItems>> response) {
                        if (response.body() != null) {
                            fullList = response.body();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<NewsItems>> call, Throwable t) {}
                });
    }

    private void loadUI(NewsItems item) {

        titleTv.setText(Html.fromHtml(item.getTitle()));
        authorTv.setText(item.getAuthorName());
        dateTv.setText(item.getFormattedDate());

        Glide.with(this)
                .load(item.getImageUrl())
                .placeholder(R.drawable.news_placeholder)
                .into(imageView);

        shareBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT,
                    item.getTitle() + "\n\nhttps://tnnews24.in/" + item.getId() + "/");
            startActivity(Intent.createChooser(i, "Share News"));
        });

        setupWebView(item.getContent());
    }

    private void setupWebView(String html) {
        WebSettings settings = webContent.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            settings.setForceDark(WebSettings.FORCE_DARK_OFF);

        String formattedHtml =
                "<html><body style='background:#FFFFFF; color:#000000;'>" +
                        (html == null ? "" : html) +
                        "</body></html>";

        webContent.setWebViewClient(new WebViewClient());
        webContent.loadDataWithBaseURL(null, formattedHtml, "text/html", "UTF-8", null);
    }

    private void setupSwipe() {
        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 40) {
                    if (dx > 0) goNext();
                    else goPrevious();
                    return true;
                }
                return false;
            }
        });

        View.OnTouchListener swipeTouch = (v, ev) -> {
            gestureDetector.onTouchEvent(ev);
            return false;
        };

        imageView.setOnTouchListener(swipeTouch);
        titleTv.setOnTouchListener(swipeTouch);
        webContent.setOnTouchListener(swipeTouch);
    }

    private void goNext() {
        if (fullList.isEmpty()) return;

        int index = findCurrentIndex();
        if (index == -1 || index == fullList.size() - 1) {
            Toast.makeText(this, "No more news", Toast.LENGTH_SHORT).show();
            return;
        }

        currentItem = fullList.get(index + 1);
        loadUI(currentItem);
        scrollView.scrollTo(0, 0);
    }

    private void goPrevious() {
        if (fullList.isEmpty()) return;

        int index = findCurrentIndex();
        if (index <= 0) {
            Toast.makeText(this, "First news", Toast.LENGTH_SHORT).show();
            return;
        }

        currentItem = fullList.get(index - 1);
        loadUI(currentItem);
        scrollView.scrollTo(0, 0);
    }

    private int findCurrentIndex() {
        for (int i = 0; i < fullList.size(); i++)
            if (fullList.get(i).getId() == currentItem.getId())
                return i;

        return -1;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        adTimerHandler.removeCallbacks(showAdRunnable); // stop ad cycle when activity closes
    }
}
