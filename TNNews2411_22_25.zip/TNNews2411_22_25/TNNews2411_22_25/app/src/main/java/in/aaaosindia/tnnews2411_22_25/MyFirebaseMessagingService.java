package in.aaaosindia.tnnews2411_22_25;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {

        // ⭐ IMPORTANT:
        // Ignore OneSignal notifications so OneSignal can handle them internally
        if (remoteMessage.getData() != null &&
                remoteMessage.getData().containsKey("onesignal")) {
            return;
        }

        String title = "";
        String message = "";
        String postId = "";

        // --- SAFE NULL CHECKS ---
        if (remoteMessage.getNotification() != null) {
            title = remoteMessage.getNotification().getTitle();
            message = remoteMessage.getNotification().getBody();
        }

        if (remoteMessage.getData() != null && remoteMessage.getData().containsKey("postId")) {
            postId = remoteMessage.getData().get("postId");
        }

        showNotification(title, message, postId);
    }

    private void showNotification(String title, String message, String postId) {

        String channelId = "tnnews_channel";

        // --------- On Notification Click → Open News Detail ---------
        Intent intent;
        if (postId != null && !postId.isEmpty()) {
            intent = new Intent(this, FullNewsActivity.class);
            intent.putExtra("postId", Integer.parseInt(postId));
        } else {
            intent = new Intent(this, MainActivity.class);
        }

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // --------- Notification Manager ---------
        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel =
                    new NotificationChannel(channelId, "TN NEWS ALERTS",
                            NotificationManager.IMPORTANCE_HIGH);
            manager.createNotificationChannel(channel);
        }

        // --------- Build Notification ---------
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, channelId)
                        .setSmallIcon(R.drawable.ic_bell)
                        .setContentTitle(title != null ? title : "TN News")
                        .setContentText(message != null ? message : "")
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                        .setAutoCancel(true)
                        .setContentIntent(pendingIntent)
                        .setPriority(NotificationCompat.PRIORITY_HIGH);

        manager.notify(1001, builder.build());
    }
}
