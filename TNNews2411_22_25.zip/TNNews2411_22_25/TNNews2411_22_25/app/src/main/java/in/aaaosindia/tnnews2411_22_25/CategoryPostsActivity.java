package in.aaaosindia.tnnews2411_22_25;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import in.aaaosindia.tnnews2411_22_25.adapter.NewsAdapter;
import in.aaaosindia.tnnews2411_22_25.data.NewsItems;
import in.aaaosindia.tnnews2411_22_25.network.ApiService;
import in.aaaosindia.tnnews2411_22_25.network.RetrofitClient;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CategoryPostsActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    NewsAdapter adapter;
    List<NewsItems> newsList = new ArrayList<>();
    Gson gson = new Gson();

    int categoryId = -1;
    String categoryName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getSupportActionBar() != null) getSupportActionBar().hide();
        setContentView(R.layout.activity_category_posts);

        categoryId = getIntent().getIntExtra("CATEGORY_ID", -1);
        categoryName = getIntent().getStringExtra("CATEGORY_NAME");

        ImageView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        recyclerView = findViewById(R.id.recyclerCategoryPosts);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new NewsAdapter(this, newsList);
        recyclerView.setAdapter(adapter);

        if (categoryId != -1) {
            loadCategoryPosts();
        }
    }

    private void loadCategoryPosts() {

        RetrofitClient.getApiService()
                .getPostsByCategoryRaw(categoryId, 20, 1, true)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                        if (!response.isSuccessful() || response.body() == null) {
                            Toast.makeText(CategoryPostsActivity.this, "Failed to load posts", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        try {
                            String raw = response.body().string();
                            Log.d("RAW_CATEGORY_POSTS", raw);

                            int start = raw.indexOf("[");
                            int end = raw.lastIndexOf("]") + 1;

                            if (start == -1 || end == -1) {
                                Toast.makeText(CategoryPostsActivity.this, "Invalid response", Toast.LENGTH_SHORT).show();
                                return;
                            }

                            String json = raw.substring(start, end);
                            Type listType = new TypeToken<List<NewsItems>>() {}.getType();
                            List<NewsItems> parsed = gson.fromJson(json, listType);

                            newsList.clear();
                            newsList.addAll(parsed);
                            adapter.notifyDataSetChanged();

                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(CategoryPostsActivity.this, "Parse error", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Toast.makeText(CategoryPostsActivity.this, "Network error", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
