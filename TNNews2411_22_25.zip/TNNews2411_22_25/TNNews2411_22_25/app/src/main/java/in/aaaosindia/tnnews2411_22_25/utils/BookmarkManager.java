package in.aaaosindia.tnnews2411_22_25.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import in.aaaosindia.tnnews2411_22_25.data.NewsItems;

public class BookmarkManager {

    private static final String PREF_NAME = "BOOKMARKS_DATA";
    private static final String KEY_BOOKMARKS = "BOOKMARK_LIST";

    // Get all bookmarks
    public static List<NewsItems> getBookmarks(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(KEY_BOOKMARKS, null);

        if (json == null) return new ArrayList<>();

        Type type = new TypeToken<List<NewsItems>>() {}.getType();
        return new Gson().fromJson(json, type);
    }

    // Save entire list
    private static void saveList(Context context, List<NewsItems> list) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        String json = new Gson().toJson(list);
        editor.putString(KEY_BOOKMARKS, json);
        editor.apply();
    }

    // Add a bookmark
    public static void saveBookmark(Context context, NewsItems item) {
        List<NewsItems> list = getBookmarks(context);

        // Avoid duplicates
        for (NewsItems saved : list) {
            if (saved.getId() == item.getId()) return;
        }

        list.add(item);
        saveList(context, list);
    }

    // Remove a bookmark
    public static void removeBookmark(Context context, int id) {
        List<NewsItems> list = getBookmarks(context);

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId() == id) {
                list.remove(i);
                break;
            }
        }

        saveList(context, list);
    }

    // Check if bookmarked
    public static boolean isBookmarked(Context context, int id) {
        for (NewsItems item : getBookmarks(context)) {
            if (item.getId() == id) return true;
        }
        return false;
    }
}
