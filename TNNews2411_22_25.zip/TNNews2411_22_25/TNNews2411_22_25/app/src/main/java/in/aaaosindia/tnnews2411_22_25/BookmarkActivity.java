package in.aaaosindia.tnnews2411_22_25;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import in.aaaosindia.tnnews2411_22_25.adapter.BookmarkAdapter;
import in.aaaosindia.tnnews2411_22_25.data.NewsItems;
import in.aaaosindia.tnnews2411_22_25.utils.BookmarkManager;

public class BookmarkActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    BookmarkAdapter adapter;
    ImageView backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmark);

        if (getSupportActionBar() != null)
            getSupportActionBar().hide();

        recyclerView = findViewById(R.id.recyclerBookmarks);
        backBtn = findViewById(R.id.backBtn);

        backBtn.setOnClickListener(v -> finish());

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<NewsItems> saved = BookmarkManager.getBookmarks(this);

        if (saved.isEmpty()) {
            Toast.makeText(this, "No bookmarks found", Toast.LENGTH_SHORT).show();
        }

        adapter = new BookmarkAdapter(this, saved);
        recyclerView.setAdapter(adapter);
    }
}
