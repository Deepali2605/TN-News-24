package in.aaaosindia.tnnews2411_22_25;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.core.widget.NestedScrollView;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.onesignal.OneSignal;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import in.aaaosindia.tnnews2411_22_25.adapter.BreakingNewsAdapter;
import in.aaaosindia.tnnews2411_22_25.adapter.CategoryAdapter;
import in.aaaosindia.tnnews2411_22_25.adapter.NewsAdapter;
import in.aaaosindia.tnnews2411_22_25.data.Category;
import in.aaaosindia.tnnews2411_22_25.data.NewsItems;
import in.aaaosindia.tnnews2411_22_25.network.RetrofitClient;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    RecyclerView categoryRecyclerView, newsRecyclerView;
    SwipeRefreshLayout swipeRefresh;
    NestedScrollView nestedScrollView;

    List<Category> categoryList = new ArrayList<>();
    CategoryAdapter categoryAdapter;

    List<NewsItems> newsList = new ArrayList<>();
    NewsAdapter newsAdapter;

    int page = 1;
    final int PAGE_SIZE = 20;
    boolean isLoading = false;

    ViewPager2 breakingSlider;
    List<NewsItems> breakingList = new ArrayList<>();
    BreakingNewsAdapter breakingAdapter;
    android.os.Handler sliderHandler = new android.os.Handler();

    TextView btnNext, btnPrev;

    Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ⭐ OneSignal v5 Initialization
        OneSignal.initWithContext(this);
        OneSignal.setAppId("54fb261e-0b0e-48c6-860c-eee10c567f3b");

        // Android 13 Notification Permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        // Ads init
        MobileAds.initialize(this, initializationStatus -> {});
        AdView bannerAd = findViewById(R.id.bannerAd);
        bannerAd.loadAd(new AdRequest.Builder().build());

        // Drawer
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        nestedScrollView = findViewById(R.id.nestedScrollView);

        // Menu
        ImageView menuIcon = findViewById(R.id.menuIcon);
        menuIcon.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        // Live
        ImageView liveIcon = findViewById(R.id.liveIcon);
        liveIcon.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, LiveActivity.class))
        );

        // Refresh
        swipeRefresh = findViewById(R.id.swipeRefresh);

        btnNext = findViewById(R.id.btnNext);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext.setVisibility(View.GONE);
        btnPrev.setVisibility(View.GONE);

        btnNext.setOnClickListener(v -> {
            if (!isLoading) {
                page++;
                fetchNews();
            }
        });

        btnPrev.setOnClickListener(v -> {
            if (page > 1 && !isLoading) {
                page--;
                fetchNews();
            }
        });

        // Category Recycler
        categoryRecyclerView = findViewById(R.id.categoryRecyclerInside);
        categoryAdapter = new CategoryAdapter(this, new ArrayList<>(), this::openCategory);
        categoryRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        categoryRecyclerView.setAdapter(categoryAdapter);

        // News Recycler
        newsRecyclerView = findViewById(R.id.newsRecyclerView);
        newsAdapter = new NewsAdapter(this, newsList);
        newsRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        newsRecyclerView.setAdapter(newsAdapter);

        // Breaking Slider
        breakingSlider = findViewById(R.id.breakingNewsSlider);

        swipeRefresh.setOnRefreshListener(() -> {
            page = 1;
            fetchCategories();
            fetchNews();
            fetchBreakingNews();
        });

        swipeRefresh.setRefreshing(true);
        fetchCategories();
        fetchNews();
        fetchBreakingNews();

        // Scroll Listener
        nestedScrollView.setOnScrollChangeListener(
                (NestedScrollView.OnScrollChangeListener) (v, scrollX, scrollY, oldScrollX, oldScrollY) -> {
                    View contentView = nestedScrollView.getChildAt(0);
                    if (contentView == null) return;

                    int bottom = contentView.getMeasuredHeight() - nestedScrollView.getMeasuredHeight();

                    if (scrollY >= bottom) {
                        btnNext.setVisibility(View.VISIBLE);
                        btnPrev.setVisibility(page > 1 ? View.VISIBLE : View.GONE);
                    } else {
                        btnNext.setVisibility(View.GONE);
                        btnPrev.setVisibility(View.GONE);
                    }
                }
        );
    }

    // ---------------- OPEN CATEGORY ----------------
    private void openCategory(String name) {
        for (Category c : categoryList) {
            if (c.getName().equals(name)) {
                Intent i = new Intent(MainActivity.this, CategoryPostsActivity.class);
                i.putExtra("CATEGORY_ID", c.getId());
                i.putExtra("CATEGORY_NAME", c.getName());
                startActivity(i);
                break;
            }
        }
    }

    // ---------------- API CALLS ----------------
    private void fetchCategories() {
        RetrofitClient.getApiService().getCategoriesRaw(100)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        swipeRefresh.setRefreshing(false);
                        try {
                            String raw = response.body().string();
                            Type type = new TypeToken<List<Category>>() {}.getType();
                            List<Category> parsed = gson.fromJson(raw, type);

                            categoryList.clear();
                            categoryList.addAll(parsed);

                            List<String> names = new ArrayList<>();
                            for (Category c : parsed) names.add(c.getName());
                            categoryAdapter.updateCategories(names);

                        } catch (Exception ignored) {}
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        swipeRefresh.setRefreshing(false);
                    }
                });
    }

    private void fetchNews() {
        isLoading = true;

        RetrofitClient.getApiService().getPostsRaw(PAGE_SIZE, page, false, "date", "desc", false)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        swipeRefresh.setRefreshing(false);
                        isLoading = false;

                        try {
                            String raw = response.body().string();
                            Type type = new TypeToken<List<NewsItems>>() {}.getType();
                            List<NewsItems> parsed = gson.fromJson(raw, type);

                            newsList.clear();
                            newsList.addAll(parsed);
                            newsAdapter.notifyDataSetChanged();

                            btnPrev.setVisibility(page > 1 ? View.VISIBLE : View.GONE);
                            btnNext.setVisibility(parsed.size() >= PAGE_SIZE ? View.VISIBLE : View.GONE);

                        } catch (Exception ignored) {}
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        swipeRefresh.setRefreshing(false);
                        isLoading = false;
                    }
                });
    }

    private void fetchBreakingNews() {
        RetrofitClient.getApiService().getStickyRaw(true, 10, 1, true)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        try {
                            String raw = response.body().string();
                            Type type = new TypeToken<List<NewsItems>>() {}.getType();
                            List<NewsItems> parsed = gson.fromJson(raw, type);

                            breakingList.clear();
                            breakingList.addAll(parsed);

                            if (breakingAdapter == null) {
                                breakingAdapter = new BreakingNewsAdapter(MainActivity.this, breakingList);
                                breakingSlider.setAdapter(breakingAdapter);
                            } else {
                                breakingAdapter.notifyDataSetChanged();
                            }

                            restartSlider();

                        } catch (Exception ignored) {}
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {}
                });
    }

    // ---------------- SLIDER ----------------
    private final Runnable slideRunnable = new Runnable() {
        @Override
        public void run() {
            if (breakingSlider.getAdapter() != null &&
                    breakingSlider.getAdapter().getItemCount() > 0) {

                int next = (breakingSlider.getCurrentItem() + 1) %
                        breakingSlider.getAdapter().getItemCount();

                breakingSlider.setCurrentItem(next, true);
            }
            sliderHandler.postDelayed(this, 3000);
        }
    };

    private void restartSlider() {
        sliderHandler.removeCallbacks(slideRunnable);
        sliderHandler.postDelayed(slideRunnable, 3000);
    }

    // ---------------- DRAWER MENU ----------------
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        drawerLayout.closeDrawer(GravityCompat.START);

        int id = item.getItemId();

        if (id == R.id.nav_home) return true;
        if (id == R.id.nav_categories) startActivity(new Intent(this, CategoryListActivity.class));
        if (id == R.id.nav_bookmark) startActivity(new Intent(this, BookmarkActivity.class));
        if (id == R.id.nav_contact) openLink("https://tnnews24.in/contact/");
        if (id == R.id.nav_noti) startActivity(new Intent(this, NotificationsActivity.class));

        if (id == R.id.nav_twitter) openLink("https://x.com/JournalistPrem3/");
        if (id == R.id.nav_fb) openLink("https://m.facebook.com/61562939211793/");
        if (id == R.id.nav_insta) openLink("https://www.instagram.com/tnnews24_/");
        if (id == R.id.nav_yt) openLink("https://www.youtube.com/@tnnews24Live");

        if (id == R.id.nav_share) shareApp();
        if (id == R.id.nav_rateus) rateApp();
        if (id == R.id.nav_privacy) openLink("https://tnnews24.in/privacy-policy/");
        if (id == R.id.nav_about) openLink("https://tnnews24.in/about-us/");
        if (id == R.id.nav_termcond) openLink("https://tnnews24.in/terms-condition/");

        return true;
    }

    // ---------------- UTILITIES ----------------
    private void openLink(String url) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(i);
    }

    private void shareApp() {
        String appLink = "https://play.google.com/store/apps/details?id=" + getPackageName();
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Check out this app");
        shareIntent.putExtra(Intent.EXTRA_TEXT, "Download TN News 24:\n" + appLink);
        startActivity(Intent.createChooser(shareIntent, "Share via"));
    }

    private void rateApp() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    // ---------------- EXIT ----------------
    @Override
    public void onBackPressed() {

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Exit App")
                .setMessage("Do you really want to exit?")
                .setCancelable(true)
                .setPositiveButton("Yes", (dialog, which) -> finishAffinity())
                .setNegativeButton("No", null)
                .show();
    }
}
