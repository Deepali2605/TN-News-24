package in.aaaosindia.tnnews2411_22_25.data;

import com.google.gson.annotations.SerializedName;

public class UserResponse {
    @SerializedName("id")
    public int id;

    @SerializedName("name")
    public String name;
}
