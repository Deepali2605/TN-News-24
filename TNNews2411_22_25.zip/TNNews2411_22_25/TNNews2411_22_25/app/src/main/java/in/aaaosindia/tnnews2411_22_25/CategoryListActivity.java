package in.aaaosindia.tnnews2411_22_25;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import in.aaaosindia.tnnews2411_22_25.adapter.CategoryListAdapter;
import in.aaaosindia.tnnews2411_22_25.data.Category;
import in.aaaosindia.tnnews2411_22_25.network.ApiService;
import in.aaaosindia.tnnews2411_22_25.network.RetrofitClient;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CategoryListActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    CategoryListAdapter adapter;

    List<Category> categoryList = new ArrayList<>();
    List<String> categoryNames = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getSupportActionBar() != null) getSupportActionBar().hide();
        setContentView(R.layout.activity_category_list);

        ImageView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        recyclerView = findViewById(R.id.recyclerViewCategories);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadCategories();
    }

    private void loadCategories() {

        ApiService api = RetrofitClient.getApiService();

        // RAW fetch because WP adds HTML junk around JSON
        api.getCategoriesRaw(100).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (!response.isSuccessful() || response.body() == null) {
                    Log.e("CategoryListActivity", "Failed to load categories");
                    return;
                }

                try {
                    String raw = response.body().string();
                    Log.d("RAW_CATEGORY", raw);

                    // Extract only JSON array from HTML/JS wrapper
                    int start = raw.indexOf("[");
                    int end = raw.lastIndexOf("]") + 1;

                    if (start == -1 || end == -1) {
                        Log.e("Category Parsing", "JSON array not found!");
                        return;
                    }

                    String cleanJson = raw.substring(start, end);
                    JSONArray arr = new JSONArray(cleanJson);

                    categoryList.clear();
                    categoryNames.clear();

                    for (int i = 0; i < arr.length(); i++) {

                        JSONObject obj = arr.getJSONObject(i);

                        int id = obj.getInt("id");
                        String name = obj.getString("name");

                        categoryList.add(new Category(id, name));
                        categoryNames.add(name);
                    }

                    adapter = new CategoryListAdapter(
                            CategoryListActivity.this,
                            categoryNames,
                            categoryName -> {

                                for (Category c : categoryList) {
                                    if (c.getName().equals(categoryName)) {

                                        Intent i = new Intent(CategoryListActivity.this, CategoryPostsActivity.class);
                                        i.putExtra("CATEGORY_ID", c.getId());
                                        i.putExtra("CATEGORY_NAME", c.getName());
                                        startActivity(i);
                                        break;
                                    }
                                }
                            }
                    );

                    recyclerView.setAdapter(adapter);

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("Category Parsing", e.getMessage());
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.e("CategoryListActivity", "API Error: " + t.getMessage());
            }
        });
    }
}
