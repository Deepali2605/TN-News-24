package in.aaaosindia.tnnews2411_22_25;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.bumptech.glide.Glide;

public class PostDetailsActivity extends AppCompatActivity {

    ImageView postImage;
    TextView postTitle;
    WebView postContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        // Remove default action bar
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        setContentView(R.layout.activity_post_details);

        postImage = findViewById(R.id.postImage);
        postTitle = findViewById(R.id.postTitle);
        postContent = findViewById(R.id.postContent);

        // Get values from adapter
        String title = getIntent().getStringExtra("TITLE");
        String image = getIntent().getStringExtra("IMAGE");
        String content = getIntent().getStringExtra("CONTENT");

        postTitle.setText(title);

        // Load image if exists
        if (image != null && !image.isEmpty()) {
            Glide.with(this).load(image).into(postImage);
        }

        // Load full HTML content in WebView
        postContent.getSettings().setJavaScriptEnabled(true);
        postContent.setWebViewClient(new WebViewClient());
        postContent.loadData(content, "text/html", "UTF-8");
    }
}
