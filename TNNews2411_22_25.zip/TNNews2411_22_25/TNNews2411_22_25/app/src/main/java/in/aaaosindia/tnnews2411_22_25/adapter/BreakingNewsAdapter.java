package in.aaaosindia.tnnews2411_22_25.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import in.aaaosindia.tnnews2411_22_25.FullNewsActivity;
import in.aaaosindia.tnnews2411_22_25.R;
import in.aaaosindia.tnnews2411_22_25.data.NewsItems;

public class BreakingNewsAdapter extends RecyclerView.Adapter<BreakingNewsAdapter.ViewHolder> {

    private final Context ctx;
    private final List<NewsItems> list;

    public BreakingNewsAdapter(Context ctx, List<NewsItems> list) {
        this.ctx = ctx;
        this.list = list != null ? list : new ArrayList<>();
    }

    // 🔥 THIS IS THE FIX YOU NEEDED
    public void updateList(List<NewsItems> newList) {
        list.clear();
        if (newList != null) {
            list.addAll(newList);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(ctx)
                .inflate(R.layout.item_breaking_slide, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NewsItems item = list.get(position);

        holder.title.setText(item.getTitle());

        Glide.with(ctx)
                .load(item.getImageUrl())
                .placeholder(R.drawable.news_placeholder)
                .into(holder.image);

        holder.itemView.setOnClickListener(v -> {
            Intent i = new Intent(ctx, FullNewsActivity.class);
            i.putExtra("postId", item.getId());
            ctx.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView title;

        ViewHolder(@NonNull View v) {
            super(v);
            image = v.findViewById(R.id.breakingImage);
            title = v.findViewById(R.id.breakingTitle);
        }
    }
}
