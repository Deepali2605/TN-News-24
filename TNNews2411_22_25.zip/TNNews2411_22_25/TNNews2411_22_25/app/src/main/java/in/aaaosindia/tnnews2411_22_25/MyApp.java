package in.aaaosindia.tnnews2411_22_25;

import android.app.Application;

import com.google.android.gms.ads.MobileAds;

public class MyApp extends Application {

    public AppOpenManager appOpenManager;

    @Override
    public void onCreate() {
        super.onCreate();

        MobileAds.initialize(this);

        // Create AppOpenManager one time
        appOpenManager = new AppOpenManager(this);
    }
}
