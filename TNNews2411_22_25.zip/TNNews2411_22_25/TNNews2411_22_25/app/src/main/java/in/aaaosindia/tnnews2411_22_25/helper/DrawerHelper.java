package in.aaaosindia.tnnews2411_22_25.helper;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import in.aaaosindia.tnnews2411_22_25.data.Category;

public class DrawerHelper {

    private DrawerLayout drawerLayout;

    public DrawerHelper(DrawerLayout drawerLayout) {
        this.drawerLayout = drawerLayout;
    }

    // Close the drawer
    public void closeDrawer() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    // Nested interface for clicks
    public interface DrawerClickListener {
        void onCategoryClicked(Category category);
    }
}
