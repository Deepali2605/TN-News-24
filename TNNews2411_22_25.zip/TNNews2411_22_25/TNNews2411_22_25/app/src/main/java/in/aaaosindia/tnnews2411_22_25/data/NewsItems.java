package in.aaaosindia.tnnews2411_22_25.data;

import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;

import java.text.SimpleDateFormat;
import java.util.List;

public class NewsItems {

    @SerializedName("id")
    private int id;

    @SerializedName("title")
    private Title title;

    @SerializedName("excerpt")
    private Excerpt excerpt;

    @SerializedName("content")
    private Content content;

    @SerializedName("date")
    private String date;

    @SerializedName("link")
    private String link;

    @SerializedName("jetpack_featured_media_url")
    private String jetpackImageUrl;

    @SerializedName("_embedded")
    private Embedded embedded;


    // ---------------- TITLE ----------------
    public static class Title {
        @SerializedName("rendered")
        String rendered;
        public String getRendered() { return rendered; }
    }

    // ---------------- EXCERPT ----------------
    public static class Excerpt {
        @SerializedName("rendered")
        String rendered;
        public String getRendered() { return rendered; }
    }

    // ---------------- CONTENT ----------------
    public static class Content {
        @SerializedName("rendered")
        String rendered;
        public String getRendered() { return rendered; }
    }


    // ---------------- EMBEDDED DATA ----------------
    public static class Embedded {

        @SerializedName("wp:featuredmedia")
        List<FeaturedMedia> featuredMedia;

        // Author can be INT or OBJECT → use JsonElement
        @SerializedName("author")
        List<JsonElement> author;

        public List<FeaturedMedia> getFeaturedMedia() { return featuredMedia; }
        public List<JsonElement> getAuthor() { return author; }
    }


    // ---------------- FEATURED MEDIA ----------------
    public static class FeaturedMedia {
        @SerializedName("source_url")
        private String sourceUrl;
        public String getSourceUrl() { return sourceUrl; }
    }


    // ---------------- GETTERS ----------------

    public int getId() { return id; }

    public String getTitle() { return title != null ? title.getRendered() : ""; }

    public String getExcerpt() { return excerpt != null ? excerpt.getRendered() : ""; }

    public String getContent() { return content != null ? content.getRendered() : ""; }

    public String getLink() { return link; }


    // ---------------- IMAGE HANDLER ----------------
    public String getImageUrl() {

        // Jetpack featured media
        if (jetpackImageUrl != null && !jetpackImageUrl.trim().isEmpty())
            return jetpackImageUrl;

        // Embedded image
        try {
            if (embedded != null &&
                    embedded.getFeaturedMedia() != null &&
                    !embedded.getFeaturedMedia().isEmpty()) {

                return embedded.getFeaturedMedia().get(0).getSourceUrl();
            }
        } catch (Exception ignored) {}

        return null;
    }


    // ---------------- AUTHOR HANDLER ----------------
    public String getAuthorName() {

        try {
            if (embedded == null || embedded.getAuthor() == null || embedded.getAuthor().isEmpty())
                return "Unknown Author";

            JsonElement element = embedded.getAuthor().get(0);

            if (element.isJsonObject()) {
                return element.getAsJsonObject().get("name").getAsString();
            }

            // If it's just an ID
            return "Author #" + element.getAsInt();

        } catch (Exception e) {
            return "Unknown Author";
        }
    }


    // ---------------- DATE FORMATTER ----------------
    public String getFormattedDate() {
        try {
            if (date == null) return "";

            String cleaned = date.replace("T", " ");

            SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            SimpleDateFormat output = new SimpleDateFormat("dd MMM yyyy");

            return output.format(input.parse(cleaned));

        } catch (Exception e) {
            return date != null ? date.split("T")[0] : "";
        }
    }
}
