package in.aaaosindia.tnnews2411_22_25.data;

public class Category {

    private int id;
    private String name;

    // ✅ REQUIRED CONSTRUCTOR (Fixes your error)
    public Category(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Optional default constructor (Retrofit may use this)
    public Category() {}

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    // setters (optional)
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }
}
