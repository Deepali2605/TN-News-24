package in.aaaosindia.tnnews2411_22_25;

import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.ui.PlayerView;

public class LiveActivity extends AppCompatActivity {

    private PlayerView playerView;
    private ExoPlayer player;
    private RelativeLayout liveHeader;
    private ImageView backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // ---------------- APPLY THEME BEFORE UI LOADS ----------------


        super.onCreate(savedInstanceState);

        // ---------------- FORCE AUTO LANDSCAPE FOR LIVE ----------------
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        setContentView(R.layout.activity_live);

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // ---------------- FIND VIEWS ----------------
        liveHeader = findViewById(R.id.liveHeader);
        backBtn = findViewById(R.id.backBtn);
        playerView = findViewById(R.id.playerView);

        // Always visible BACK BUTTON (independent)
        backBtn.bringToFront();
        backBtn.setOnClickListener(v -> finish());

        // ---------------- SETUP EXOPLAYER ----------------
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        playerView.setKeepScreenOn(true);

        String streamUrl = "https://accountapk.livebox.co.in/TNNEWS24hls/live.m3u8";
        MediaItem mediaItem = MediaItem.fromUri(Uri.parse(streamUrl));
        player.setMediaItem(mediaItem);
        player.prepare();
        player.setPlayWhenReady(true);

        // ---------------- HIDE RED HEADER BUT KEEP BACK BUTTON ----------------
        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                if (isPlaying) {
                    liveHeader.setVisibility(View.GONE);
                    backBtn.setVisibility(View.VISIBLE); // back always visible
                }
            }
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null)
            player.setPlayWhenReady(false);
    }

    @Override
    protected void onStop() {
        super.onStop();
        releasePlayer();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releasePlayer();
    }

    private void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
