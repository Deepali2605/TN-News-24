package in.aaaosindia.tnnews2411_22_25.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.interstitial.InterstitialAd;

import java.util.ArrayList;
import java.util.List;

import in.aaaosindia.tnnews2411_22_25.FullNewsActivity;
import in.aaaosindia.tnnews2411_22_25.R;
import in.aaaosindia.tnnews2411_22_25.data.NewsItems;
import in.aaaosindia.tnnews2411_22_25.utils.BookmarkManager;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {

    private final Context context;
    private List<NewsItems> newsList = new ArrayList<>();

    public NewsAdapter(Context context, List<NewsItems> newsList) {
        this.context = context;
        this.newsList = newsList;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_news, parent, false);
        return new NewsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        NewsItems item = newsList.get(position);
        if (item == null) return;

        // ---- TITLE ----
        holder.title.setText(item.getTitle() != null ? item.getTitle() : "");

        // ---- DATE ----
        String date = item.getFormattedDate();
        if (date == null) date = "";
        holder.date.setText(date);

        // ---- IMAGE ----
        String imageUrl = item.getImageUrl();
        if (imageUrl != null && !imageUrl.trim().isEmpty()) {
            Glide.with(context)
                    .load(imageUrl)
                    .placeholder(R.drawable.news_placeholder)
                    .error(R.drawable.news_placeholder)
                    .into(holder.image);
        } else {
            holder.image.setImageResource(R.drawable.news_placeholder);
        }

        // ---- OPEN FULL NEWS ----
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, FullNewsActivity.class);
            intent.putExtra("postId", item.getId());
            context.startActivity(intent);
        });

        // ---- SHARE ----
        holder.share.setOnClickListener(v -> {
            String url = "https://tnnews24.in/" + item.getId() + "/";

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT,
                    (item.getTitle() != null ? item.getTitle() : "") + "\n\n" + url);

            context.startActivity(Intent.createChooser(shareIntent, "Share News"));
        });

        // ---- BOOKMARK: SET INITIAL ICON ----
        if (BookmarkManager.isBookmarked(context, item.getId())) {
            holder.bookmark.setImageResource(R.drawable.bookmark_filled);
        } else {
            holder.bookmark.setImageResource(R.drawable.bookmark);
        }

        // ---- BOOKMARK CLICK ----
        holder.bookmark.setOnClickListener(v -> {

            if (BookmarkManager.isBookmarked(context, item.getId())) {

                BookmarkManager.removeBookmark(context, item.getId());
                holder.bookmark.setImageResource(R.drawable.bookmark);
                Toast.makeText(context, "Removed from bookmarks", Toast.LENGTH_SHORT).show();

            } else {

                BookmarkManager.saveBookmark(context, item);
                holder.bookmark.setImageResource(R.drawable.bookmark_filled);
                Toast.makeText(context, "Bookmarked", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return newsList != null ? newsList.size() : 0;
    }

    public void updateNews(List<NewsItems> newList) {
        this.newsList = newList;
        notifyDataSetChanged();
    }

    public void addMore(List<NewsItems> more) {
        int start = newsList.size();
        newsList.addAll(more);
        notifyItemRangeInserted(start, more.size());
    }

    public static class NewsViewHolder extends RecyclerView.ViewHolder {

        ImageView image, bookmark, share;
        TextView title, date;

        public NewsViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.newsImage);
            title = itemView.findViewById(R.id.newsTitle);
            date = itemView.findViewById(R.id.newsDate);
            bookmark = itemView.findViewById(R.id.bookmarkIcon);
            share = itemView.findViewById(R.id.shareIcon);
        }
    }
}
