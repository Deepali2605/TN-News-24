package in.aaaosindia.tnnews2411_22_25;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class SplashActivity extends AppCompatActivity {

    private static final long SPLASH_DELAY = 1500L;
    private boolean moved = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ImageView logo = findViewById(R.id.splashLogo);
        logo.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));

        new Handler(Looper.getMainLooper()).postDelayed(this::tryShowAd, SPLASH_DELAY);
    }

    private void tryShowAd() {

        if (moved) return;
        moved = true;

        MyApp app = (MyApp) getApplication();

        app.appOpenManager.showAdIfAvailable(this::goHome);
    }

    private void goHome() {
        startActivity(new Intent(SplashActivity.this, MainActivity.class));
        finish();
    }
}
