package in.aaaosindia.tnnews2411_22_25;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

public class AppOpenManager implements Application.ActivityLifecycleCallbacks {

    private final Application myApp;

    public AppOpenAd appOpenAd = null;
    public Activity currentActivity = null;

    public boolean isShowing = false;
    public boolean hasShownThisLaunch = false;

    // ⭐ YOUR REAL APP OPEN AD ID
    private static final String APP_OPEN_AD_ID = "ca-app-pub-5389304191356684/5002154041";

    public AppOpenManager(Application app) {
        myApp = app;
        app.registerActivityLifecycleCallbacks(this);
        loadAd();
    }

    public void loadAd() {
        AdRequest request = new AdRequest.Builder().build();

        AppOpenAd.load(
                myApp,
                APP_OPEN_AD_ID,   // ⭐ USING YOUR REAL ID HERE
                request,
                AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                new AppOpenAd.AppOpenAdLoadCallback() {

                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd ad) {
                        Log.d("APP_OPEN", "Ad Loaded Successfully (REAL)");
                        appOpenAd = ad;
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError error) {
                        Log.e("APP_OPEN", "Ad Failed: " + error.getMessage());
                        appOpenAd = null;
                    }
                }
        );
    }

    public void showAdIfAvailable(Runnable onFinish) {

        if (appOpenAd == null || isShowing || hasShownThisLaunch || currentActivity == null) {
            onFinish.run();
            return;
        }

        isShowing = true;

        appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {

            @Override
            public void onAdDismissedFullScreenContent() {
                isShowing = false;
                hasShownThisLaunch = true;
                appOpenAd = null;
                loadAd();
                onFinish.run();
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) {
                isShowing = false;
                hasShownThisLaunch = true;
                onFinish.run();
            }

            @Override
            public void onAdShowedFullScreenContent() {
                appOpenAd = null;
            }
        });

        appOpenAd.show(currentActivity);
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override public void onActivityCreated(@NonNull Activity a, Bundle b) {}
    @Override public void onActivityStarted(@NonNull Activity a) {}
    @Override public void onActivityPaused(@NonNull Activity a) {}
    @Override public void onActivityStopped(@NonNull Activity a) {}
    @Override public void onActivitySaveInstanceState(@NonNull Activity a, @NonNull Bundle out) {}
    @Override public void onActivityDestroyed(@NonNull Activity a) {}
}
